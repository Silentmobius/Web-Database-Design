drop database if exists jlim5db;
create database if not exists jlim5db;
use jlim5db;
CREATE TABLE relationshipTable (
	id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    Description NVARCHAR(50) NOT NULL
);
INSERT INTO relationshipTable (Description)
    VALUES ('Classmate'), ('Mentor'), ('Instructor'), ('Other'), ('Supervisor');
    
CREATE TABLE referencesTable (
	id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    relationshipId INT UNSIGNED NOT NULL,
    firstName nvarchar(255) NOT NULL,
    lastName nvarchar(255) NOT NULL,
    phoneNumber nvarchar(255) NOT NULL,
    email nvarchar (255) NOT NULL,
    
	CONSTRAINT FOREIGN KEY relationship_FK (relationshipId)
		REFERENCES relationshipTable (id)
);
CREATE TABLE messageTable (
	id int unsigned auto_increment not null primary key,
    firstName nvarchar(255) NOT NULL,
    lastName nvarchar(255) NOT NULL,
    email nvarchar(255) NOT NULL,
    messageSentDate DATETIME NULL
);
CREATE TABLE users(
	id int unsigned auto_increment not null primary key,
	userName nvarchar(255) not null,
    firstName nvarchar(255) not null,
    lastName nvarchar(255) not null,
	registrationDate DATETIME NULL,
    pass_hash char(60) not null,
    unique(userName)
);
CREATE TABLE `Tiers` (
	`id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `Description` NVARCHAR(50) NOT NULL
);
INSERT INTO `Tiers` (`Description`)
	VALUES  ('Front-end'),
			('Back-end'),
			('Object-Oriented'),
            ('Other');
CREATE TABLE `Programming_Languages` (
	`id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `Language` NVARCHAR(50) NOT NULL,
    `Tier_id` INT UNSIGNED,
    
	CONSTRAINT FOREIGN KEY `Tier_FK` (`Tier_id`)
		REFERENCES `Tiers` (`id`)
);
CREATE TABLE images(
	`id` int unsigned not null auto_increment,
    `filename` nvarchar(255) not null,
    `type` nvarchar(50) not null,
    `data` longblob,
    primary key(`id`)
);
SELECT * from images;