<!DOCTYPE html>
<html lang="en">
<head>
<title><?php echo $page_title ?></title>
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php
session_start();
require ("./includes/mysqli_connect.php");
require ("./includes/functions.inc.php");
?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style type="text/css" title="text/css" media="all">
</style>
<script type="text/javascript" charset="utf-8" src="./js/jquery-3.3.1.min.js"></script>
<script>
$(document).ready(function(){
	$("#tigerImg").click(function(){
		alert("ROARRRRR");
	});
	$("#chickenImage").click(function() {
		alert("BOK BOK BOK");
	});
	$("#foxImage").click(function() {
		alert("Grrrrrrr");
	});
	$("#golfImage").click(function() {
		alert("Classh");
	});
	$("#chickenInfo").hide();
	$("#foxInfo").hide();
	$("#golfInfo").hide();
	$("#chickenButton").click(function(){
		$("#chickenInfo").fadeToggle();
	});
	$("#foxLogo").click(function(){
		$("#foxInfo").fadeToggle();
	});
	$("#foxImage").click(function() {
		$("#foxInfo").fadeToggle();
	});
	$("#golfButton").click(function(){
		$("#golfInfo").fadeToggle();
	});
});
</script>
</head>
<body>
<div id="wrapper1">
<header>
<?php
if (isset($_SESSION['ImageID']) AND isset($_SESSION['ImageFileName'])){
		echo "<img id='mainLogo' class='float-left' src=get-image.php?id={$_SESSION['ImageID']}alt={$_SESSION['ImageFileName']}/>";
}
?>
<h1 class='clear' id="headerBanner">Portfolio</h1>
</header>
<nav>
<!--<header>
<img src="./uploads/Capture.PNG" alt="logo"></img>
<h1 >PORTFOLIO</h1>
</header> -->
<?php

echo '<ul>';
if (isset($_SESSION['ID']) && isset($_SESSION['Username']) && basename($_SERVER['PHP_SELF']) != 'loggedout.php') {
	echo "<li><a href='loggedout.php'>LOG OUT</a></li>";
	echo "<li><a href='users.php'>REGISTERED USERS</a></li>";
	echo '<li><a href="newUpdate.php">UPDATE PASSWORD</a></li>';
	echo '<li class="dropdown"><a href="images.php" class="dropbtn">IMAGES</a>';
	if ($_SESSION['Username'] == 'Jimmy') {
	echo '
		<div class="dropdown-content">
			<a href="upload_image.php">UPLOAD IMAGE</a>
		</div>
		</li></nav></ul>
	<nav id="navBar2"><ul>
	<li><a href="loggedin.php">HOME</a></li>
	<li class="dropdown"><a href="#" class="dropbtn">ABOUT ME</a>
		<div class="dropdown-content">
			<a href="missionstatement.php">MISSION STATEMENT</a>
			<a href="hobbies.php">HOBBIES</a>
		</div>
	</li>
	<li class="dropdown"><a href="viewReferences.php" class="dropbtn">REFERENCES</a>
		<div class="dropdown-content">
			<a href="addReferences.php">ADD</a>
		</div> 
	</li>
	<li class="dropdown"><a href="viewLanguages.php" class="dropbtn">LANGUAGES</a>
		<div class="dropdown-content">
			<a href="addLanguages.php">ADD</a>
		</div> 
	</li>
	<li class="dropdown"><a href="email.php" class="dropbtn">CONTACT</a>
		<div class="dropdown-content">
			<a href="viewMessengers.php">View Messengers</a>
		</div>
	</li>
	</ul></nav></div>';
	} else {
		echo '</li></nav></ul>
	<nav id="navBar2"><ul>
	<li><a href="loggedin.php">HOME</a></li>
	<li class="dropdown"><a href="#" class="dropbtn">ABOUT ME</a>
		<div class="dropdown-content">
			<a href="missionstatement.php">MISSION STATEMENT</a>
			<a href="hobbies.php">HOBBIES</a>
		</div>
	</li>
	<li><a href="viewReferences.php">REFERENCES</a></li>
	<li class="dropdown"><a href="viewLanguages.php" class="dropbtn">LANGUAGES</a>
	</li>
	<li><a href="email.php">CONTACT</a></li>
	</ul></nav></div>';
	}

} else {
	echo "<li><a href='index.php'>LOG IN</a></li>";
	echo "<li><a href='register.php'>REGISTER</a></li>";
}
echo '</ul>';
?>
</nav>
<!--
<li><a href="images.php">Images</a></li>
<li><a href="show_image.php">Show Image</a></li>
-->
</div>
