<?php
$page_title = "Login";
?>
<?php 
if (isset($errors) && !empty($errors)){
	echo '<h1>Error!</h1>
	<p class="error">The following error(s) have occured.</p><br>';
	foreach ($errors as $msg){
		echo "$msg\n";
	}
	echo '<p>Please try again</p>';
}
			
?>
<h1>Login</h1>
<form action="index.php" method="post">
	<label><p>Username:</p><input type="text" name="username" size="20" maxlength="60" /></label>
	<label><p>Password: </p><input type="password" name="password" size="20" maxlength="20"></label>
	<br><br><input  type="submit" name="submit" value="Login">
</form>

<?php
include ("./includes/footer.inc.html");
exit();
?>