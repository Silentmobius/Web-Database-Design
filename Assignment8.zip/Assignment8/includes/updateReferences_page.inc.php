<?php 
if (isset($_GET['id'])){
	$id = $_GET['id'];
	$q = "SELECT id, relationshipId, firstName, lastName, phoneNumber, email FROM referencesTable WHERE id = $id;";
	$r = mysqli_query($dbc, $q);
	if (mysqli_num_rows($r) == 1) {
		$row = mysqli_fetch_array($r, MYSQLI_ASSOC);
		$getOldRelationship = $row['relationshipId'];
		$getOldFirstName = $row['firstName'];
		$getOldLastName = $row['lastName'];
		$getOldPhoneNumber = $row['phoneNumber'];
		$getOldEmail = $row['email'];
	}
}

if (isset($errors) && !empty($errors)){
	echo '<h1>Error!</h1>
	<p class="error">The following error(s) have occured.</p>';
	foreach ($errors as $msg){
		echo "$msg\n";
	}
	echo '<p>Please try again</p>';
}
?>

<h1>Update References</h1>
<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <fieldset>
    <legend><p>Change Reference</p></legend>
	<p>Required *</p>
	<p>Relationship: *
    <input type="hidden" name="oldRelationship" value="<?php echo isset($getOldRelationship) ? $getOldRelationship : '' ?>"><br>
	<select name="newRelationship">
		<option></option>
		<option value="1" <?php echo (isset($getOldRelationship) && $getOldRelationship == 1) ? 'selected' : ''?>>Classmate</option>
		<option value="2" <?php echo (isset($getOldRelationship) && $getOldRelationship == 2) ? 'selected' : ''?>>Mentor</option>
		<option value="3" <?php echo (isset($getOldRelationship) && $getOldRelationship == 3) ? 'selected' : ''?>>Instructor</option>
		<option value="4" <?php echo (isset($getOldRelationship) && $getOldRelationship == 4) ? 'selected' : ''?>>Other</option>
		<option value="5" <?php echo (isset($getOldRelationship) && $getOldRelationship == 5) ? 'selected' : ''?>>Supervisor</option>
	</select><br></p>
    <p>First Name: *
    <input type="hidden" name="oldFirstName" value="<?php echo isset($getOldFirstName) ? $getOldFirstName : ''?>"><br>
    <input type="text" name="newFirstName" value="<?php echo isset($getOldFirstName) ? $getOldFirstName : ''?>"><br></p>
    <p>Last Name: *
    <input type="hidden" name="oldLastName" value="<?php echo isset($getOldLastName) ? $getOldLastName : ''?>"><br>
    <input type="text" name="newLastName" value="<?php echo isset($getOldLastName) ? $getOldLastName : ''?>"><br></p>
    <p>Phone Number: *
    <input type="hidden" name="oldPhoneNumber" value="<?php echo isset($getOldPhoneNumber) ? $getOldPhoneNumber : '' ?>"><br> 
    <input type="text" name="newPhoneNumber" value="<?php echo isset($getOldPhoneNumber) ? $getOldPhoneNumber : '' ?>"><br></p>
	<p>Email: *
    <input type="hidden" name="oldEmail" value="<?php echo isset($getOldEmail) ? $getOldEmail : '' ?>"><br> 
    <input type="text" name="newEmail" value="<?php echo isset($getOldEmail) ? $getOldEmail : '' ?>"><br></p>
	<br>
    <input type="submit" value="Submit"><br><br>
  </fieldset><br><br><br><br>
</form>

