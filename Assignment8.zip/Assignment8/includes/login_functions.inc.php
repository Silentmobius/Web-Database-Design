<?php
	function redirect_user ($page = 'index.php'){
		$url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
		$url = rtrim($url, '/\\');
		$url .= '/' . $page;
		
		header("Location: $url");
		exit();
	}
	
	//Returns $row['ASSOC'] or $errors[];
	function check_login($dbc, $username = '', $pass = '') {
		$errors = array();
		
		if (empty($username)){
			$errors[] = '<p>You forgot to enter your username.</p>';
		} else {
			$username = mysqli_real_escape_string($dbc, trim($username));
		}
		if (empty($pass)){
			$errors[] = '<p>You forgot to enter a password</p>';
			
		} else {
			$password = mysqli_real_escape_string($dbc, trim($pass));
		}
		
		if (empty($errors)){
			$q = "SELECT id, username, pass_hash FROM users WHERE username ='$username'";
			$r = mysqli_query($dbc, $q);
			if (mysqli_num_rows($r) == 1) {
				$row = mysqli_fetch_array($r, MYSQLI_ASSOC);
					if (!password_verify($password, $row['pass_hash'])) {
					$errors[] =  '<p>Invalid password!</p>';
					} else {
						return array(true, $row);
					}
			} else {
				$errors[] = '<p>User not found in the database</p>';
			}
		}
		return array(false, $errors);
	}
	function check_languages($dbc, $oldLanguage = '', $oldTier = '') {
		$errors = array();
		
		if (empty($oldLanguage)){
			$errors[] = '<p>You forgot to enter the language.</p>';
		} else {
			$oldLanguage = mysqli_real_escape_string($dbc, trim($oldLanguage));
		}
		if (empty($oldTier)){
			$errors[] = '<p>You forgot to select a tier</p>';
			
		} else {
			$oldTier = mysqli_real_escape_string($dbc, trim($oldTier));
		}
		
		if (empty($errors)){
			
			$q = "SELECT id, Language, Tier_id FROM Programming_Languages WHERE Language = '$oldLanguage';";
			$r = mysqli_query($dbc, $q);
			if (mysqli_num_rows($r) == 1) {
				$row = mysqli_fetch_array($r, MYSQLI_ASSOC);
					if ($oldTier != $row['Tier_id']) {
					$errors[] =  '<p>Tier is incorrect</p>';
					} else {
						return array(true, $row);
					}
			} else {
				$errors[] = '<p>Language not found in the database</p>';
			}
		}
		return array(false, $errors);
	}
	//list($check, $data) = check_references($dbc, $_POST['relationship'], $_POST['firstName'] , $_POST['lastName'], $_POST['phoneNumber'], $_POST['email']);
	function check_references($dbc, $relationship = '', $firstName = '', $lastName = '', $phoneNumber = '', $email = '',
		$oldRelationship = '', $oldFirstName = '', $oldLastName = '', $oldPhoneNumber = '', $oldEmail = '') {
		$errors = array();
		
		if (empty($relationship)){
			$errors[] = '<p>You forgot to select the relationship.</p>';
		} else {
			$relationship = mysqli_real_escape_string($dbc, trim($relationship));
		}
		if (empty($firstName)){
			$errors[] = '<p>Empty first name field</p>';
		} else {
			$firstName = mysqli_real_escape_string($dbc, trim($firstName));
		}
		if (empty($lastName)) {
			$errors[] = '<p>Empty last name field</p>';
		} else {
			$lastName = mysqli_real_escape_string($dbc, trim($lastName));
		}
		if (empty($phoneNumber)){
			$errors[] = '<p>Empty phone number field</p>';
		} else {
			$phoneNumber = mysqli_real_escape_string($dbc, trim($phoneNumber));
		}
		if (empty($email)){
			$errors[] = '<p>Empty email field</p>';
		} else {
			$email = mysqli_real_escape_string($dbc, trim($email));
		}
		
		if (empty($errors)){
			
			$q = "SELECT id, relationshipId, firstName, lastName, phoneNumber, email FROM referencesTable WHERE relationshipId = $oldRelationship AND firstName = '$oldFirstName' AND lastName = '$oldLastName' AND phoneNumber = '$oldPhoneNumber' AND email = '$oldEmail';";
			$r = mysqli_query($dbc, $q);
			if (mysqli_num_rows($r) == 1) {
				$row = mysqli_fetch_array($r, MYSQLI_ASSOC);
					return array(true, $row);
			} else {
				$errors[] = '<p>Language not found in the database</p>';
			}
		}
		return array(false, $errors);
	}
