<?php
//hostname, username, db_name
//alternative $dbc = new mysqli()
$dbc = @mysqli_connect('localhost', 'root', '', 'jlim5db') OR die('Could not connect to MySQL: ' . mysqli_connect_error() );
mysqli_set_charset($dbc, 'utf8');

?>