
<?php
if (isset($errors) && !empty($errors)){
	echo '<h1>Error!</h1>
	<p class="error">The following error(s) have occured.</p>';
	foreach ($errors as $msg){
		echo "$msg";
	}
	echo '<p>Please try again</p>';
}
			
?>
<h1>Update Password</h1>
<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <fieldset class="clear-left width-60">
    <legend><p>Change Password</p></legend>
	<p>Required *</p>
    <p>User ID: *</p>
    <input type="text" name="userID" value="<?php echo isset($getUserName) ? $getUserName : '' ?>"><br>
	<p>Password *</p>
	<input type="password" name="oldPassword" value=""/><br>
	<p>New Password *</p>
	<input type="password" name="newPassword" value=""/><br>
	<p>Confirm Password *</p>
	<input type="password" name="confirmPassword" value=""/><br><br>
    <input type="submit" value="Submit">
  </fieldset>
</form>
