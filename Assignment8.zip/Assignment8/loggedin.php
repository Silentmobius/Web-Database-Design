<?php
$page_title = "Main";
include ("./includes/header.inc.php");
include ('./includes/login_functions.inc.php');
	if (!isset($_SESSION['Agent']) OR $_SESSION['Agent'] != md5($_SERVER['HTTP_USER_AGENT'])){
		
		redirect_user();
		
	} else {
		$page_title = "Loggedin";
		echo "<h1 id='welcomeBanner' class='whiteText text-center'>WELCOME TO THE HOMEPAGE {$_SESSION['Username']}!</h1>";
		echo '
		<div class="bg-1 container-fluid text-center">
		<h2>Who Am I?</h2>';

		if (isset($_SESSION['HomeImage']) AND isset($_SESSION['HomeImageFileName'])){
			echo "<img class='img-circle' src=get-image.php?id={$_SESSION['HomeImage']}alt={$_SESSION['HomeImageFileName']}/>";
		} else {
			echo '<img id="tigerImg" src="./images/tiger.PNG" alt="Tiger" class="img-circle">';
		}
		
		echo '
		<h3>Im an adventurer</h3>
		</div>
		
		<div class="container-fluid bg-2 text-center">
			<h2>What Am I?</h2>
			<h3>Grassroots Developer</h3>
			
			
		</div>
		
		<div class="container-fluid bg-3 text-center">
		<h2>Where To Find Me?</h2>
		<a target="_blank" href="https://www.linkedin.com/in/037911/" class="fa fa-linkedin"></a>
		<a target="_blank" href="https://github.com/Silentmobius" class="fa fa-github"></a>
		</div>
		
		';
		
	}



include ("./includes/footer.inc.html");
?>