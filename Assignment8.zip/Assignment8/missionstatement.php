<?php
$page_title = "Mission Statement";
include ("./includes/header.inc.php");
?>
<div class="missionbg-1 container-fluid text-center">
		<h2>MISSION STATEMENT</h2>
		<?php
		if (isset($_SESSION['MissionImage']) AND isset($_SESSION['MissionImageFileName'])){
			echo "<img class='img-circle' src=get-image.php?id={$_SESSION['MissionImage']}alt={$_SESSION['MissionImageFileName']}/>";
		} else {
			echo "<img class='img-circle' src='./images/WoW.PNG' alt='WoW'>";
		}
		?>
		<h3>To become an employee of a new company for someone else's mission statement</h3>
		</div><?php
include ("./includes/footer.inc.html");
exit();
?>