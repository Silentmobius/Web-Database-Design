<?php
$page_title = "Images";
include ("./includes/header.inc.php");
if ($_SERVER['REQUEST_METHOD'] == "POST" AND isset($_GET['id']) AND isset($_POST['change'])) {
		$selection = $_POST['change'];
		$dbc = new mysqli('localhost','root','','jlim5db');
		$q = 'SELECT * FROM images WHERE id =' . $_GET['id'];
		$r = mysqli_query($dbc, $q);
		if ($r){
			$row = mysqli_fetch_array($r, MYSQLI_ASSOC);
			switch ($selection) {
				case 'header':
					$_SESSION['ImageID'] = $row['id'];
					$_SESSION['ImageFileName'] = $row['filename'];
					header ('location: images.php'); break;
				case 'm.s':
					$_SESSION['MissionImage'] = $row['id'];
					$_SESSION['MissionImageFileName'] = $row['filename']; break;
				case 'home':
					$_SESSION['HomeImage'] = $row['id'];
					$_SESSION['HomeImageFileName'] = $row['filename'];
			}
		}	
	
}

?>
<ul>
<?php
$q = 'SELECT * FROM images';
$r = mysqli_query($dbc, $q);
if ($r) {
	while ($row = mysqli_fetch_array($r, MYSQLI_ASSOC)){
		if (isset($row['id']) AND isset($row['filename'])) {
			
			echo '<br><div class="gallery"><form method="POST" action="images.php?id=' . $row['id'] .'">' .
				"<a target='_blank' href='get-image.php?id={$row['id']}alt={$row['filename']}'>" .
				"<img id='img-gallery' src=get-image.php?id={$row['id']}alt={$row['filename']}/>" .
				'</a>';
			echo ($_SESSION['Username'] == 'Jimmy') ?
				'<p><input type="radio" name="change" value="header" checked>Header</input></p>
				<p><input type="radio" name="change" value="m.s">Mission Statement</input></p>
				<p><input type="radio" name="change" value="home">Home</input></p>
				<div class="desc">
					<input type="submit" value="Set Logo">
				</div>
				</form></div>' : '</form></div>';
			
		}

	}
}
?>
</ul>
</body>
</html>