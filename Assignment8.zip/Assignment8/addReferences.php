<?php
$page_title = "Add References";
include ("./includes/header.inc.php");
?>
<?php
$relationshipErr = $fnErr = $lnErr = $phoneErr = $emailErr = "";
$r = FALSE;
	if ($_SERVER['REQUEST_METHOD'] == "POST"){
		if (empty($_POST['relationship'])) {
			$relationshipErr = "Please select a relationship.";
		} else {
			//mysqli function provides extra security against hackers that may attack the database
			$relationship = mysqli_real_escape_string($dbc, trim($_POST['relationship']));
		}
		if (empty($_POST['firstName'])){
			$fnErr = "Please enter the first name.";
		} else {
			$firstName = mysqli_real_escape_string($dbc, trim($_POST['firstName']));
		}
		if (empty($_POST['lastName'])){
			$lnErr = "Please enter the last name.";
		} else {
			$lastName = mysqli_real_escape_string($dbc, trim($_POST['lastName']));
		}
		if (empty($_POST['phoneNumber'])){
			$phoneErr = "Please enter a phone number";
		} else {
			$phone = mysqli_real_escape_string($dbc, trim($_POST['phoneNumber']));
		}
		if (empty($_POST['email'])){
			$emailErr = "Please enter an email";
		} else {
			$email = mysqli_real_escape_string($dbc, trim($_POST['email']));
		}
		if (!empty($relationship) && !empty($firstName) && !empty($lastName) && !empty($phone) && !empty($email)) {
			$_POST = array();
			//Query
			$q = "INSERT INTO referencesTable (relationshipId, firstName, lastName, phoneNumber, email)
				 VALUES ($relationship, '$firstName', '$lastName', '$phone', '$email');";
			//Execute the query with $r becoming TRUE or FALSE
			$r = mysqli_query($dbc, $q);
			//Validate query was made
			
			if (mysqli_affected_rows($dbc) == 1){
				echo "<p>Reference Added</p>";
				$relationship = $firstName = $lastName = $phone = $email = '';
			} else {
				echo "<p>WTF</p>";
			}
			//Close the db (optional)

			mysqli_close($dbc);
		} else {
			echo mysqli_error($dbc);
		}
	}
//Debugging tools
//print_r($userErr); var_dump();
?>
<form class="clear-left width-60" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <fieldset>
    <legend><h1>ADD REFERENCE</h1></legend>
	<p>Required *</p>
	<p>Relationship:
		<select name="relationship">
		<option></option>
		<option value="1" <?php echo (isset($relationship) && $relationship == 1) ? 'selected' : ''?>>Classmate</option>
		<option value="2" <?php echo (isset($relationship) && $relationship == 2) ? 'selected' : ''?>>Mentor</option>
		<option value="3" <?php echo (isset($relationship) && $relationship == 3) ? 'selected' : ''?>>Instructor</option>
		<option value="4" <?php echo (isset($relationship) && $relationship == 4) ? 'selected' : ''?>>Other</option>
		<option value="5" <?php echo (isset($relationship) && $relationship == 5) ? 'selected' : ''?>>Supervisor</option>
		</select>
	<span class="error">*<?php if(empty($_POST['relationship'])) echo $relationshipErr ?></span></p>
	<p>First Name *</p>
	<input type="text" name="firstName" value="<?php echo (isset($firstName)) ? $firstName : ''?>"/><span class="error">*<?php echo (empty($_POST['firstName'])) ? $fnErr : ''?></span>
	<p>Last Name *</p>
	<input type="text" name="lastName" value="<?php echo (isset($lastName)) ? $lastName : ''?>"/><span class="error">*<?php echo (empty($_POST['lastName'])) ? $lnErr : ''?></span><br><br>
	<p>Phone Number *</p>
	<input type="text" name="phoneNumber" value="<?php echo (isset($phone)) ? $phone : ''?>"/><span class="error">*<?php echo (empty($_POST['phoneNumber'])) ? $phoneErr : ''?></span><br><br>
	<p>Email *</p>
	<input type="text" name="email" value="<?php echo (isset($email)) ? $email : ''?>"/><span class="error">*<?php echo (empty($_POST['email'])) ? $emailErr : ''?></span><br><br>
    <input type="submit" value="Submit">
  </fieldset>
</form>
<?php
	if ($r == TRUE) {
		echo '<p>Never stop learning</p>';
	}
?>
<?php
include ("./includes/footer.inc.html");
exit();
?>