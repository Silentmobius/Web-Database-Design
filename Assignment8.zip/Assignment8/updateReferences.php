<?php
$page_title = "Update Reference";
include ("./includes/header.inc.php");
require ('./includes/login_functions.inc.php');

if (isset($_GET['id'])) {
	$id = $_GET['id'];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST'){
		list($check, $data) = check_references($dbc,$_POST['newRelationship'],$_POST['newFirstName'], $_POST['newLastName'], $_POST['newPhoneNumber'], $_POST['newEmail'],
		$_POST['oldRelationship'], $_POST['oldFirstName'], $_POST['oldLastName'], $_POST['oldPhoneNumber'], $_POST['oldEmail']);
		if ($check){
			$id = $data['id'];
			$newRelationship = $_POST['newRelationship'];
			$firstName = $_POST['newFirstName'];
			$lastName = $_POST['newLastName'];
			$phone = $_POST['newPhoneNumber'];
			$email = $_POST['newEmail'];
		$q = "UPDATE referencesTable SET relationshipId = $newRelationship, firstName = '$firstName', lastName = '$lastName', phoneNumber = '$phone', email = '$email' WHERE id =$id;";
				$r = mysqli_query($dbc, $q);
				$numAffected = mysqli_affected_rows($dbc);
				if ($numAffected == 1){
					echo "<p>Thank you.  You've successfully updated the reference.</p>";
				} else {
					echo "Fuck";
					echo mysqli_error($dbc);
				}
		mysqli_close($dbc);
		} else {
			$errors = $data;
		}
}

include ('./includes/updateReferences_page.inc.php');


?>
<?php
include ("./includes/footer.inc.html");
exit();
?>