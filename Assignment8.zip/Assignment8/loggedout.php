<?php
$page_title = "Logged Out";
include ("./includes/header.inc.php");
include ('./includes/login_functions.inc.php');
	if (isset($_SESSION['ID']) && isset($_SESSION['Username'])){
		$page_title = "Logging out";
		$_SESSION = array(); //removes data from the session
		session_destroy(); //deletes session on the server
		setcookie ('PHPSESSID'); //deletes session on the browser
		//setcookie('ID'); 
		//setcookie('Username');
		//Client cookie remains, but cookie sent by server will delete this cookie
		echo "<p>You've successfully logged out.  Goodbye</p>";
		header ('location: loggedout.php');
	} else {
		echo "<p>You've successfully logged out.  Goodbye</p>";
	}
include ("./includes/footer.inc.html");
?>