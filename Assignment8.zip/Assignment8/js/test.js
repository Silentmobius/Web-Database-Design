$(function() {
	alert('Ready!');
});
$('a'); //Selects every a link
$('img.landscape'); //Selects every image with the class landscape.
$('#register ul'); //Selects all ul of the id register.