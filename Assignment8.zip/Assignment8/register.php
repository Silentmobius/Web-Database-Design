<?php
$page_title = "Register";
include ("./includes/header.inc.php");
?>
<?php
$userErr = $passErr = $confirmPassErr = $fnErr = $lnErr = "";
$r = FALSE;
	if ($_SERVER['REQUEST_METHOD'] == "POST"){
		if (empty($_POST['userID'])) {
			$userErr = "Please enter your username";
		} else {
			//mysqli function provides extra security against hackers that may attack the database
			$userID = mysqli_real_escape_string($dbc, trim($_POST['userID']));
		}
		if (empty($_POST['firstName'])){
			$fnErr = "Please enter your first name";
		} else {
			$firstName = mysqli_real_escape_string($dbc, trim($_POST['firstName']));
		}
		if (empty($_POST['lastName'])){
			$lnErr = "Please enter your last name";
		} else {
			$lastName = mysqli_real_escape_string($dbc, trim($_POST['lastName']));
		}
		if (empty($_POST['password'])){
			$passErr = "Please enter a password";
		} else {
			$password = mysqli_real_escape_string($dbc, trim($_POST['password']));
			$hash = password_hash($password, PASSWORD_DEFAULT);
		}
		if (empty($_POST['confirmPassword'])){
			$confirmPassErr = "Please confirm your password.";
		} else {
				if ($_POST['password'] != $_POST['confirmPassword']){
					echo "<p>Passwords do not match.  Try again.</p>";
				} else {
					$confirmPass = $_POST['confirmPassword'];
				}
		}
		if (!empty($userID) && !empty($password) && !empty($confirmPass) && !empty($firstName) && !empty($lastName)){

			//Query
			$q = "INSERT INTO users (userName, firstName, lastName, pass_hash, registrationDate) VALUES ('$userID', '$firstName', '$lastName', '$hash', NOW());";
			//Execute the query with $r becoming TRUE or FALSE
			$r = mysqli_query($dbc, $q);
			//Validate query was made
			if ($r){
				echo "<p>You've successfully registered!</p>";
				$_POST = array();
			} else {
				echo "<p>That username already exists.</p>";
				
			}
			//Close the db (optional)
			mysqli_close($dbc);
		}

	}
//Debugging tools
//print_r($userErr); var_dump();
?>
<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <fieldset>
    <legend><h1>Register</h1></legend>
	<p>Required *</p>
    <p>User ID: *</p>
    <input type="text" name="userID" value="<?php if (isset($_POST['userID'])) echo $_POST['userID']?>"><span class="error">*<?php if(empty($_POST['userID'])) echo $userErr ?></span><br>
	<p>First Name: *</p>
    <input type="text" name="firstName" value="<?php if (isset($_POST['firstName'])) echo $_POST['firstName']?>"><span class="error">*<?php if(empty($_POST['firstName'])) echo $fnErr ?></span><br>
	<p>Last Name: *</p>
    <input type="text" name="lastName" value="<?php if (isset($_POST['lastName'])) echo $_POST['lastName']?>"><span class="error">*<?php if(empty($_POST['lastName'])) echo $lnErr ?></span><br>
	<p>Password *</p>
	<input type="password" name="password" value=""/><span class="error">*<?php if(empty($_POST['password'])) echo $passErr ?></span><br>
	<p>Confirm Password *</p>
	<input type="password" name="confirmPassword" value=""/><span class="error">*<?php if(empty($_POST['confirmPassword'])) echo $confirmPassErr ?></span><br><br>
    <input type="submit" value="Submit">
  </fieldset>
</form>
<?php
	if ($r == TRUE) {
		welcome($userID);
	}
?>
<?php
include ("./includes/footer.inc.html");
exit();
?>