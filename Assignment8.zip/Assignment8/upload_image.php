<?php
$page_title = "Update";
include ("includes/header.inc.php");
require ('./includes/login_functions.inc.php');
?>
<?php 
function handleUpload() : void {
	if (!isset($_FILES['upload'])) {
		return; // no file :(
	}

	$db = new mysqli('localhost','root','','jlim5db');
	$file = $_FILES['upload'];

	$filename = $file['name'];
	$size = $file['size'];
	$type = $file['type'];
	$errors = $file['error'];
	$tmpPath = $file['tmp_name'];

	if(empty($tmpPath)){
		echo'<p>file[tmp_name] is null</p>';
		return;
	}
	/** 
	 * use fileinfo to check encoding to verify file type 
	 */
	$allowedTypes = [
		'image/jpeg',
		'image/pjpeg',
		'image/X-PNG',
		'image/jpg',
		'image/png',
		'image/gif',
		'image/JPG',
	];
	$finfo = new finfo(FILEINFO_MIME_TYPE);
	
	if (!in_array($finfo->file($tmpPath), $allowedTypes)) {
		echo '<p>File type not allowed! Type: ' . $finfo->file($tmpPath) . '</p>';
		return;
	}

	/**
	 * if we want to move the file to permanent location
	 */
	// if (file_exists($tmpPath)) {
	// 	move_uploaded_file($tmpPath, 'uploads/' . $filename);

	// 	echo '<p>file moved successfully</p>';
	// }
	
	/** 
	 * extract raw img data and save as BLOB in database  
	 */
	$stream = fopen($tmpPath, 'r');
	$data = fread($stream, $size);
	fclose($stream);

	$stmt = $db->prepare('INSERT images(filename, type, data) values(?,?,?)');
	$stmt->bind_param('sss', $filename, $type, $data);
	
	if ($errors > 0) {
		echo '<p class="error">The file could not be uploaded because: <strong>';
		switch ($_FILES['upload']['error']) {
			case 1:
				print 'The file exceeds the upload_max_filesize setting in php.ini.';
				break;
			case 2:
				print 'The file exceeds the MAX_FILE_SIZE setting in the HTML form.';
				break;
			case 3:
				print 'The file was only partially uploaded.';
				break;
			case 4:
				print 'No file was uploaded.';
				break;
			case 6:
				print 'No temporary folder was available.';
				break;
			case 7:
				print 'Unable to write to the disk.';
				break;
			case 8:
				print 'File upload stopped.';
				break;
			default:
				print 'A system error occurred.';
				break;
		} 
		print '</strong></p>';
	}
	if (!$stmt->execute()) {
		echo $stmt->error;
		return;
	}

	print '<p>file uploaded successfully</p>';
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	handleUpload();
} 
?>

<form enctype="multipart/form-data" action="upload_image.php" method="post">

<!--	<input type="hidden" name="MAX_FILE_SIZE" value="524288"> -->
	<fieldset class="clear-left width-60">
	<legend><p>Select a JPEG or PNG image of 512KB or smaller to be uploaded:</p></legend>
	<p><strong>File:</strong> <input type="file" name="upload"></p>
	</fieldset>
	<br>
	<div align="center"><input type="submit" name="submit" value="Submit"></div>

</form>
</body>
</html>