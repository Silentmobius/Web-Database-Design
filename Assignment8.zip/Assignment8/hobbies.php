<?php
$page_title = "Hobbies";
include ("./includes/header.inc.php");
?>
<div class="hobbiesbg-1 container-fluid">
	<h1 id="hobbiesLogo" class="text-center">HOBBIES</h1>
	
	<h3 id="chickenButton"><img id="chickenImage" src="./images/rooster.PNG" alt="Rooster" width="200px" height="200px" class="img-circle float-left">
	Chicken Farming (Info)</h3>
	<p id="chickenInfo">Poultry farming is the process of raising domesticated birds such as chickens, ducks, turkeys and geese for the purpose of farming meat or eggs for food.</p>
	<p class="clear-left"></p>
	<div class="float-right"><img id="foxImage" src="./images/fox.PNG" alt="Rooster" width="200px" height="200px" class="img-circle float-right">
	<h3 id="foxLogo">Fox Hunting (Info)</h3>
	<p id="foxInfo">Fox hunting is an activity involving the tracking, chase and, if caught, the killing of a fox, traditionally a red fox, by trained foxhounds.</p>
	</div>
	
	<p class="clear-right"></p>
	<h3 id="golfButton"><img id="golfImage" src="./images/disc_golf.PNG" alt="Disc Golf" width="200px" height="200px" class="img-circle float-left">
	Playing Disc Golf (Info)</h3>
	<p id="golfInfo" >Disc Golf is a flying disc sport in which players throw a disc at a target; it is played using rules similar to golf.</p>
	<p class="clear-left"></p>
</div>
<?php
include ("./includes/footer.inc.html");
exit();
?>