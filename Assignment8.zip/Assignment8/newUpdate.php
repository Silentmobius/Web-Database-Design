<?php
$page_title = "Update";
include ("./includes/header.inc.php");
require ('./includes/login_functions.inc.php');
?>
<?php
if (isset($_GET['id'])){
	$id = $_GET['id'];
	$q = "SELECT userName, firstName, lastName from users where id = $id;";
	$r = mysqli_query($dbc, $q);
	if ($r) {
		$row = mysqli_fetch_array($r, MYSQLI_ASSOC);
		$getUserName = $row['userName'];
	}
}
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
	list($check, $data) = check_login($dbc, $_POST['userID'], $_POST['oldPassword']);
	if ($check){
		
		$_SESSION['ID'] = $data['id'];
		$_SESSION['Username'] = $data['username'];
		
		$_SESSION['Agent'] = md5($_SERVER['HTTP_USER_AGENT']);
		//setcookie('ID', $data['id']);
		//setcookie('Username', $data['username']);
		if ($_POST['oldPassword'] == $_POST['newPassword']){
			$errors[] = "<p>New password is the same as the old one.</p>";
		} else if ($_POST['newPassword'] != $_POST['confirmPassword']){
			$errors[] = "<p>New password and Confirmation do not match.</p>";
		} else if (empty($_POST['newPassword']) OR empty($_POST['confirmPassword'])){
				$errors[] = "<p>New password and Confirmation password boxes are empty</p>";
		} else {
			
			
			$userID = $_POST['userID'];
			$newPassword = $_POST['newPassword'];
			$qq = "SELECT id, pass_hash FROM users WHERE username='$userID'";
			$rr = mysqli_query($dbc, $qq);
			$num = mysqli_num_rows($rr);
			if ($num == 1) {
				$row = mysqli_fetch_array($rr, MYSQLI_ASSOC);
				$q = 'UPDATE users SET pass_hash = "' . password_hash($newPassword, PASSWORD_DEFAULT) . '" WHERE id =' . $row['id'];
				$r = mysqli_query($dbc, $q);
				$numAffected = mysqli_affected_rows($dbc);
				if ($numAffected == 1){
					echo "<p>Thank you.  You've successfully updated your password.</p>";
				} else {
					echo mysqli_error($dbc);
				}
			} else {
				echo "User not found in the database";
			}
		}
	mysqli_close($dbc);
	} else {
			$errors = $data;
	}
}
include ('./includes/update_page.inc.php');


?>
<?php
include ("./includes/footer.inc.html");
exit();
?>